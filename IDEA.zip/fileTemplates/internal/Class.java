#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @project ${PROJECT_NAME}
* @package ${PACKAGE_NAME}
* @author ${USER}
* @date ${DATE} ${TIME}
*/
public class ${NAME} {
}
